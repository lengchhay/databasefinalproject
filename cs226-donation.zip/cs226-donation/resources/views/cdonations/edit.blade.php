@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Edit Cash Donation</h1>
    <form action="{{ route('cdonations.update', $cdonation->cdonationId) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label class="form-label">Cash Donation Purpose</label>
            <input type="text" class="form-control" name="cdonationName" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Amount</label>
            <input type="text" class="form-control" name="cdonationPrice" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Payment Method</label>
            <input type="text" class="form-control" name="cdonationPayment" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Date</label>
            <input type="date" class="form-control" name="cdonationContact" value="{{ $cdonation->cdonationDate }}" required>
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
</div>
@endsection