@extends('layouts.app')
@section('content')
<div class="container">
    
    <h1>Cash Donations List</h1>
   

    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Donation Purpose</th>
                <th scope="col">Amount</th>
                <th scope="col">Payment Method</th>
                <th scope="col">Date</th>
                <th scope="col">Action</th>


        </thead>
        <tbody>
            @foreach ($cdonations as $cdonation)
            <tr>
                <th scope="row">{{$cdonation->cdonationId}}</th>
                <td>{{$cdonation->cdonationName}}</td>
                <td>{{$cdonation->cdonationPrice}}</td>
                <td>{{$cdonation->cdonationPayment}}</td>
                <td>{{$cdonation->cdonationDate}}</td>
                <td class="d-flex"><a href="{{ route('cdonations.edit', $cdonation->cdonationId) }}" type="button" class="btn btn-secondary">Edit</a><form action="{{ route('cdonations.destroy', $cdonation->cdonationId) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form></td>
            </tr>
            @endforeach
        </tbody>
    </table>


</div>
@endsection