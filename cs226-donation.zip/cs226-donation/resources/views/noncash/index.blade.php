@extends('layouts.app')
@section('content')
<div class="container">
  <br>  
<h1>Cash Donations List</h1>
    
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Donation Purpose</th>
                <th scope="col">Description</th>
                <th scope="col">Quantity</th>
                <th scope="col">Delivery</th>
                <th scope="col">Date</th>
                <th scope="col">Action</th>


        </thead>
        <tbody>
            @foreach ($noncashs as $noncash)
            <tr>
                <th scope="row">{{$noncash->noncashId}}</th>
                <td>{{$noncash->noncashDe}}</td>
                <td>{{$noncash->noncashQuantity}}</td>
                <td>{{$noncash->noncashDelivery}}</td>
                <td>{{$noncash->noncashDate}}</td>
                <td class="d-flex"><a href="{{ route('noncashs.edit', $noncash->noncashId) }}" type="button" class="btn btn-secondary">Edit</a><form action="{{ route('noncashs.destroy', $noncash->noncashId) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form></td>
            </tr>
            @endforeach
        </tbody>

    </table>
    <a href="{{ route('noncashs.create') }}"><button type="button" class="btn btn-success">Add more ... </button></a>

    
</div>


@endsection