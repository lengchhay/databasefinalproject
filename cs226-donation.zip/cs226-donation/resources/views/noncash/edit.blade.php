@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Edit Non Cash Donation</h1>
    <form action="{{ route('noncashs.update', $noncash->NonCashId) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label class="form-label">Donation Description</label>
            <input type="text" class="form-control" name="noncashDe" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Quantity</label>
            <input type="text" class="form-control" name="noncashQuantity" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Delivery</label>
            <input type="text" class="form-control" name="noncashDelivery" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Contact</label>
            <input type="interger" class="form-control" name="NonCashContact" required>
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
</div>
@endsection