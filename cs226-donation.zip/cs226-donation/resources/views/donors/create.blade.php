@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Register New Donor</h1>
    
    <form id = "form1" action="{{ route('donors.store') }}" method="POST" onsubmit="return false">
        @csrf
        
        <div class="mb-3">
            <label class="form-label">Donor Name</label>
            <input type="text" class="form-control" name="DonorName" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Address</label>
            <input type="text" class="form-control" name="DonorAddress" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Contact</label>
            <input type="text" class="form-control" name="DonorContact" required>
        </div>
        <button type="submit" class="btn btn-primary">I confirm the information is right</button>
    </form>





    <form id = "form2" action="{{ route('cdonations.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label class="form-label">Cash Donation Purpose</label>
            <input type="text" class="form-control" name="cdonationName" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Amount</label>
            <input type="text" class="form-control" name="cdonationPrice" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Payment Method</label>
            <input type="text" class="form-control" name="cdonationPayment" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Date</label>
            <input type="date" class="form-control" name="cdonationDate" required>
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
   
 

</div>

