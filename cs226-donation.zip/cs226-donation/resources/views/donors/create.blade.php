@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Register New Donor</h1>
    <form action="{{ route('donors.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label class="form-label">Donor Name</label>
            <input type="text" class="form-control" name="DonorName" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Address</label>
            <input type="text" class="form-control" name="DonorAddress" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Contact</label>
            <input type="text" class="form-control" name="DonorContact" required>
        </div>
        <button type="submit" class="btn btn-primary">Register</button>
    </form>
</div>
@endsection