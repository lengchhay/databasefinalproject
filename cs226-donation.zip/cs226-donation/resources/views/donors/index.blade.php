@extends('layouts.app')
@section('content')
<div class="container">
    
    <h1>Current Donors List</h1>
    <a href="{{ route('donors.create') }}"><button type="button" class="btn btn-success">Register New Donors</button></a>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Full Name</th>
                <th scope="col">Address</th>
                <th scope="col">Contact</th>
                <th scope="col">Action</th>


        </thead>
        <tbody>
            @foreach ($donors as $donor)
            <tr>
                <th scope="row">{{$donor->DonorId}}</th>
                <td>{{$donor->DonorName}}</td>
                <td>{{$donor->DonorAddress}}</td>
                <td>{{$donor->DonorContact}}</td>
                <td class="d-flex"><a href="{{ route('donors.edit', $donor->DonorId) }}" type="button" class="btn btn-secondary">Edit</a><form action="{{ route('donors.destroy', $donor->DonorId) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form></td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection