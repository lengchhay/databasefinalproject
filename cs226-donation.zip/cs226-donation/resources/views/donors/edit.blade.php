@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Edit Donor</h1>
    <form action="{{ route('donors.update', $donor->DonorId) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label class="form-label">Donor Name</label>
            <input type="text" class="form-control" name="DonorName" value="{{ $donor->DonorName }}" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Address</label>
            <input type="text" class="form-control" name="DonorAddress" value="{{ $donor->DonorAddress }}" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Contact</label>
            <input type="text" class="form-control" name="DonorContact" value="{{ $donor->DonorContact }}" required>
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
</div>
@endsection