@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Donation Report</h1>
    <a href="{{ route('donors.index') }}"><button type="button" class="btn btn-primary">View Donors</button></a>
    <a href="{{ route('cdonations.index') }}"><button type="button" class="btn btn-success">View Cash Donations</button></a>
</div>
@endsection