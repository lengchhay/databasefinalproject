
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Register New Donor</h1>
    <form action="<?php echo e(route('donors.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Donor Name</label>
            <input type="text" class="form-control" name="DonorName" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Address</label>
            <input type="text" class="form-control" name="DonorAddress" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Contact</label>
            <input type="text" class="form-control" name="DonorContact" required>
        </div>
        <button type="submit" class="btn btn-primary">Register</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tanlengchhay/Downloads/cs226-donation/resources/views/donors/create.blade.php ENDPATH**/ ?>