
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Cash Donation</h1>
    <form action="<?php echo e(route('cdonations.update', $cdonation->cdonationId)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">Cash Donation Purpose</label>
            <input type="text" class="form-control" name="cdonationName" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Amount</label>
            <input type="text" class="form-control" name="cdonationPrice" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Payment Method</label>
            <input type="text" class="form-control" name="cdonationPayment" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Date</label>
            <input type="date" class="form-control" name="cdonationContact" value="<?php echo e($cdonation->cdonationDate); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tanlengchhay/Downloads/cs226-donation 2/resources/views/cdonations/edit.blade.php ENDPATH**/ ?>