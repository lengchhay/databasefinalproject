
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Donation Report</h1>
    <a href="<?php echo e(route('donors.create')); ?>"><button type="button" class="btn btn-success">Register New Donors</button></a>
    <a href="<?php echo e(route('donors.index')); ?>"><button type="button" class="btn btn-primary">View Donors</button></a>
    <a href="<?php echo e(route('cdonations.index')); ?>"><button type="button" class="btn btn-success">View Cash Donations</button></a>
    
   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tanlengchhay/Downloads/cs226-donation 2/resources/views/dashboard.blade.php ENDPATH**/ ?>