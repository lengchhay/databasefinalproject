
<?php $__env->startSection('content'); ?>
<div class="container">
    
    <h1>Cash Donations List</h1>
   

    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Donation Purpose</th>
                <th scope="col">Amount</th>
                <th scope="col">Payment Method</th>
                <th scope="col">Date</th>
                <th scope="col">Action</th>


        </thead>
        <tbody>
            <?php $__currentLoopData = $cdonations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdonation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($cdonation->cdonationId); ?></th>
                <td><?php echo e($cdonation->cdonationName); ?></td>
                <td><?php echo e($cdonation->cdonationPrice); ?></td>
                <td><?php echo e($cdonation->cdonationPayment); ?></td>
                <td><?php echo e($cdonation->cdonationDate); ?></td>
                <td class="d-flex"><a href="<?php echo e(route('cdonations.edit', $cdonation->cdonationId)); ?>" type="button" class="btn btn-secondary">Edit</a><form action="<?php echo e(route('cdonations.destroy', $cdonation->cdonationId)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tanlengchhay/Downloads/cs226-donation 2/resources/views/cdonations/index.blade.php ENDPATH**/ ?>