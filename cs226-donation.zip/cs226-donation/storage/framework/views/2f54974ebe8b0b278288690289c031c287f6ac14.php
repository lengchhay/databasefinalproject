
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Dashboard</h1>
    <a href="<?php echo e(route('donors.index')); ?>"><button type="button" class="btn btn-primary">View Donors</button></a>
    <a href="<?php echo e(route('subscriptions.index')); ?>"><button type="button" class="btn btn-success">View Subscriptions</button></a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tanlengchhay/Downloads/cs226-gym-1/resources/views/dashboard.blade.php ENDPATH**/ ?>