
<?php $__env->startSection('content'); ?>
<div class="container">
    
    <h1>Current Donors List</h1>
  

    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Full Name</th>
                <th scope="col">Address</th>
                <th scope="col">Contact</th>
                <th scope="col">Action</th>


        </thead>
        <tbody>
            <?php $__currentLoopData = $donors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($donor->DonorId); ?></th>
                <td><?php echo e($donor->DonorName); ?></td>
                <td><?php echo e($donor->DonorAddress); ?></td>
                <td><?php echo e($donor->DonorContact); ?></td>
                <td class="d-flex"><a href="<?php echo e(route('donors.edit', $donor->DonorId)); ?>" type="button" class="btn btn-secondary">Edit</a><form action="<?php echo e(route('donors.destroy', $donor->DonorId)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tanlengchhay/Downloads/cs226-donation 2/resources/views/donors/index.blade.php ENDPATH**/ ?>