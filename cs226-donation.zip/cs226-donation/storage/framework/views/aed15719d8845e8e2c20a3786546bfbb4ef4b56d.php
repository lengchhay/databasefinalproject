
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Dashboard</h1>
    <a href="<?php echo e(route('customers.index')); ?>"><button type="button" class="btn btn-primary">View Customers</button></a>
    <a href="<?php echo e(route('subscriptions.index')); ?>"><button type="button" class="btn btn-success">View Subscriptions</button></a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\wampstack-8.0.7-0\apache2\htdocs\cs226-gym\resources\views/dashboard.blade.php ENDPATH**/ ?>