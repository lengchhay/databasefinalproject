
<?php $__env->startSection('content'); ?>
<div class="container">
    
    <h1>Customers List</h1>
    <a href="<?php echo e(route('customers.create')); ?>"><button type="button" class="btn btn-success">Create Customers</button></a>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Full Name</th>
                <th scope="col">Address</th>
                <th scope="col">Contact</th>
                <th scope="col">Action</th>


        </thead>
        <tbody>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($customer->CustomerId); ?></th>
                <td><?php echo e($customer->CustomerName); ?></td>
                <td><?php echo e($customer->CustomerAddress); ?></td>
                <td><?php echo e($customer->CustomerContact); ?></td>
                <td class="d-flex"><a href="<?php echo e(route('customers.edit', $customer->CustomerId)); ?>" type="button" class="btn btn-secondary">Edit</a><form action="<?php echo e(route('customers.destroy', $customer->CustomerId)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tanlengchhay/Downloads/cs226-gym-1/resources/views/customers/index.blade.php ENDPATH**/ ?>