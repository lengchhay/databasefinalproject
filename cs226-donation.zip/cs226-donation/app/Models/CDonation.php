<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CDonation extends Model
{
    public $table = 'cdonations';
    use HasFactory;
    protected $primaryKey = 'cdonationId';
    protected $fillable = [
        'cdonationId','cdonationName', 'cdonationPrice','cdonationPayment','cdonationDate'
    ];
}
