<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NonCash extends Model
{
    public $table = 'noncashs';
    use HasFactory;
    protected $primaryKey = 'noncashId';
    protected $fillable = [
        'noncashId','noncashDe', 'noncashQuantity','noncashDelivery','noncashDate'
    ];
}
