<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CDonation;

class CDonationsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cdonations = CDonation::all();
        return view('cdonations.index')->with('cdonations', $cdonations);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('cdonations.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'cdonationName' => 'required',
            'cdonationPrice' => 'required',
            'cdonationPayment' => 'required',
            'cdonationDate' => 'required',
        ]);

        CDonation::create($request->all());
        return redirect()->route('cdonations.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(CDonation $cdonation)
    {
        return view('cdonations.edit', compact('cdonation'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,CDonation $cdonation)
    {
        $request->validate([]);
        $cdonation->update($request->all());
        return redirect()->route('cdonations.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(CDonation $cdonation)
    {
        $cdonation->delete();
        return redirect()->route('cdonations.index');

    }
}
