<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\NonCash;

class NonCashsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $noncashs = NonCash::all();
        return view('noncashs.index')->with('noncashs', $noncashs);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('noncashs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'noncashDe' => 'required',
            'noncashQuantity' => 'required',
            'noncashDelivery' => 'required',
            'noncashDate' => 'required',
        ]);

        NonCash::create($request->all());
        return redirect()->route('noncashs.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(NonCash $noncash)
    {
        return view('noncashs.edit', compact('noncash'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,NonCash $noncash)
    {
        $request->validate([]);
        $noncash->update($request->all());
        return redirect()->route('noncashs.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(NonCash $noncash)
    {
        $noncash->delete();
        return redirect()->route('noncashs.index');

    }
}
