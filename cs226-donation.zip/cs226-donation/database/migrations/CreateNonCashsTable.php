<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNonCashsTable extends Migration


{
    
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('noncashs', function (Blueprint $table) {
            $table->increments('noncashId');
            $table->string('noncashDe');
            $table->interger('noncashQuantity');
            $table->string('noncashDelivery');
            $table->date('noncashDate');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('noncashs');
    }
}
