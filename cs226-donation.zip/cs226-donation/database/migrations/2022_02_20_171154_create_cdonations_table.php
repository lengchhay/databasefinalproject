<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCDonationsTable extends Migration


{
    
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cdonations', function (Blueprint $table) {
            $table->increments('cdonationId');
            $table->string('cdonationName');
            $table->date('cdonationDate');
            $table->string('cdonationPayment');
            $table->integer('cdonationPrice');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cdonations');
    }
}
